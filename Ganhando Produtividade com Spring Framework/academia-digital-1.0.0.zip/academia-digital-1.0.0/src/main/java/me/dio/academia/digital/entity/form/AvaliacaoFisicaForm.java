package me.dio.academia.digital.entity.form;

import me.dio.academia.digital.entity.Aluno;

public class AvaliacaoFisicaForm {

  private Long alunoId;

  private double peso;

  private double altura;
}
